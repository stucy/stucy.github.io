//Used for encapsulating elements that do not need a parent for styling
const Aux = ({children}) => children;

export default Aux;