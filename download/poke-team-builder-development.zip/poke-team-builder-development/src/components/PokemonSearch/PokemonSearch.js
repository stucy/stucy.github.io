import React from 'react';

import './PokemonSearch.css';

const PokemonSearch = ({click, change, pokemon, openModal}) =>{
    
    return (
        <div className="SearchContainer">
            
        </div>
    )
}

export default PokemonSearch;